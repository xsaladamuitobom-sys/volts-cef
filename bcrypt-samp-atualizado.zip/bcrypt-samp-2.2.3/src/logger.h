#ifndef BCRYPT_LOGGER_H
#define BCRYPT_LOGGER_H

#include <sstream>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <ctime>
#include <mutex>
#include <atomic>

enum class BcryptLogLevel
{
    trace = 0,
    debug = 1,
    info = 2,
    warning = 3,
    error = 4,
    fatal = 5
};

class BcryptLogger
{
public:
    static void init(const char *filename)
    {
        std::lock_guard<std::mutex> lock(mutex());
        file().open(filename, std::ios::out | std::ios::app);
        setLevel(BcryptLogLevel::error);
    }

    static void setLevel(BcryptLogLevel level)
    {
        currentLevel().store(static_cast<int>(level));
    }

    static bool enabled(BcryptLogLevel level)
    {
        return static_cast<int>(level) >= currentLevel().load();
    }

    static void write(BcryptLogLevel level, const std::string &message)
    {
        std::lock_guard<std::mutex> lock(mutex());

        if (!file().is_open())
            return;

        const char *names[] = {
            "trace", "debug", "info",
            "warning", "error", "fatal"
        };

        std::time_t now = std::time(NULL);
        std::tm timestamp;

        localtime_r(&now, &timestamp);

        file() << std::put_time(&timestamp, "%Y-%m-%d %H:%M:%S")
               << " <" << names[static_cast<int>(level)] << "> "
               << message << std::endl;
    }

private:
    static std::ofstream &file()
    {
        static std::ofstream instance;
        return instance;
    }

    static std::mutex &mutex()
    {
        static std::mutex instance;
        return instance;
    }

    static std::atomic<int> &currentLevel()
    {
        static std::atomic<int> instance(
            static_cast<int>(BcryptLogLevel::error)
        );
        return instance;
    }
};

class BcryptLog : public std::ostringstream
{
public:
    explicit BcryptLog(BcryptLogLevel level)
        : level_(level)
    {
    }

    ~BcryptLog()
    {
        if (BcryptLogger::enabled(level_))
            BcryptLogger::write(level_, str());
    }

private:
    BcryptLogLevel level_;
};

#define BOOST_LOG_TRIVIAL(level) BcryptLog(BcryptLogLevel::level)

#endif
